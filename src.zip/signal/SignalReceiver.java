package signal;

public class SignalReceiver
{
	public void onReceive(String sigName,String[] msg) {}
}
