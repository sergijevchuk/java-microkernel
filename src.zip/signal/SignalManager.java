package signal;
import java.util.*;
import java.io.*;

public class SignalManager
{
	private static class Cell {
		private String name;
		private SignalReceiver r;
		public Cell(String name,SignalReceiver rex) {
			this.name = name;
			r = rex;
		}
		public String getName() {
			return name;
		}
		public SignalReceiver getReceiver() {
			return r;
		}
	}
	private static ArrayList<Cell> cl;
	public static void init() {
		cl = new ArrayList<Cell>();
	}
	public static void add(String name,SignalReceiver r) {
		Cell c = new Cell(name,r);
		cl.add(c);
	}
	public static void send(String fo,String signal,String... other) {
		for (int i = 0; i < cl.size(); i++) {
			if (cl.get(i).getName().equalsIgnoreCase(fo)) {
				cl.get(i).getReceiver().onReceive(signal,other);
			}
		}
	}
	public static void shutdown() {
		cl.clear();
	}
}
