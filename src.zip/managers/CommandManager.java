package managers;
import java.util.*;
import managers.commands.*;
import proc.*;

public class CommandManager
{
	private static HashMap<String,Command> commands;
	public static void init() {
		commands = new HashMap<String,Command>();
	}
	public static void add(String name,Command exec) {
		if (!commands.containsKey(name)) {
		commands.put(name,exec);
		}
	}
	public static void remove(String name) {
		if (commands.containsKey(name)) {
			commands.remove(name);
		}
	}
	public static void exec(final String name,final String[] args) {
		if (commands.containsKey(name)) {
			final Command c = commands.get(name);
			MyRunnable r = new MyRunnable() {

				@Override
				public void run()
				{
					c.execute(args);
				}
				
				public void onTerminated() {
					System.out.println("Command " + name + " terminnated!");
				}
				
			};
			ProcessManager.addApp(name,r);
			ProcessManager.getProcess(name).waitForPrc();
		} else {
			System.out.println("Command " + name + " not found!");
		}
	}
	public static void clear() {
		commands.clear();
	}
	public static void shutdown() {
		if (commands != null) {
			commands.clear();
		}
	}
	private static String[] getArgs(String c) {
		return null;
	}
}
