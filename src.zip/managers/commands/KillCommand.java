package managers.commands;
import signal.*;
import proc.*;

public class KillCommand extends Command
{

	@Override
	public void execute(String[] args)
	{
		// TODO: Implement this method
		if (args.length != 0) {
			SignalManager.send(args[0],ProcessSignals.SIGNAL_TERM);
		} else {
			System.out.println("kill: required process name!");
		}
	}
	
}
