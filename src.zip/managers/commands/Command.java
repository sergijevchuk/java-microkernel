package managers.commands;

public class Command
{
	public void execute(String[] args) {}
	public void onKilled() {}
}
