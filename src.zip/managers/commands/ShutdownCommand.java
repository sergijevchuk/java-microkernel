package managers.commands;
import kernel.*;
import managers.*;
import kernel.utils.*;
import signal.*;

public class ShutdownCommand extends Command
{

	@Override
	public void execute(String[] args)
	{
		// TODO: Implement this method
		KernelConfig.isShuttingDown = true;
		KernelConfig.isShell = false;
		printk.printk("shutdown: shutting down...");
		KernelConfig.isShuttingDown = true;
		SignalManager.send("kernel","shutdown","test");
	}
	
}
