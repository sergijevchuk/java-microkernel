package managers.commands;
import managers.*;
import kernel.*;
import kernel.utils.*;

public class PanicCommand extends Command
{

	@Override
	public void execute(String[] args)
	{
		// TODO: Implement this method
		KernelConfig.isShell = false;
		KernelConfig.isShuttingDown = false;
		new Panic().panic("Custom panic");
	}
	
}
