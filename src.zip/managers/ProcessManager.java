package managers;
import java.util.*;
import proc.*;
import signal.*;

public class ProcessManager
{
	private static HashMap<String,MyProcess> apps;
	public static void init() {
		apps = new HashMap<String,MyProcess>();
	}
	public static void addApp(String name,MyRunnable main) {
		MyProcess p = new MyProcess(name,main);
		apps.put(name,p);
	}
	public static void kill(String name) {
		if (apps.containsKey(name)) {
			apps.get(name).shutdown();
			SignalManager.send(name,ProcessSignals.SIGNAL_TERM);
			apps.remove(name);
		}
	}
	public static MyProcess getProcess(String name) {
		
		return apps.get(name);
	}
	public static void killall() {
		if (apps != null) {
		Object[] prc = apps.keySet().toArray();
		for (int i = 0; i < prc.length; i++) {
			kill(prc.toString());
		}
		}
	}
	public static void waitForAll() {
		if (apps != null) {
		Object[] prc = apps.keySet().toArray();
		for (int i = 0; i < prc.length; i++) {
			System.out.println("Waiting for " + apps.get(prc[i].toString()).getName());
			apps.get(prc[i].toString()).waitForPrc();
			apps.remove(prc[i].toString());
		}
		}
	}
	public static void shutdown() {
		if (apps != null) {
			killall();
			apps.clear();
		}
	}
}
