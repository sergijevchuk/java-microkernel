package proc;
import java.util.*;
import signal.*;

public class MyProcess extends SignalReceiver
{
	private ArrayList<Thread> th;
	private String name;
	private MyRunnable main;
	public MyProcess(String name,MyRunnable main) {
		th = new ArrayList<>();
		this.main = main;
		SignalManager.add(name,this);
		this.name = name;
		addThread(name,main);
	}
	public void addThread(String name,MyRunnable main) {
		Thread m = new Thread(main);
		m.setName(name);
		th.add(m);
		m.start();
	}
	public void shutdown() {
		for (int i = 0; i < th.size(); i++) {
			try {
				th.get(i).join();
			} catch (InterruptedException e) {
				System.out.println(name + ": shutting down: failed kill thread: " + th.get(i).getName());
			}
			th.remove(i);
		}
	}
	public void waitForPrc() {
		for (int i = 0; i < th.size(); i++) {
			while (th.get(i).isAlive()) {}
			th.remove(i);
		}
	}
	public String getName() {
		return name;
	}
	
	public void onTerminated() {
		if (main != null) {
			main.onTerminated();
		}
	}
	
	@Override
	public void onReceive(String sigName, String[] msg)
	{
		// TODO: Implement this method
		if (sigName.equalsIgnoreCase(ProcessSignals.SIGNAL_TERM)) {
			onTerminated();
		} else if (sigName.equalsIgnoreCase(ProcessSignals.SIGNAL_KILL)) {
			shutdown();
		}
	}
	
}
