package proc;

public class MyRunnable implements Runnable
{

	@Override
	public void run()
	{
		// TODO: Implement this method
	}

	public void onTerminated() {
		
	}
}
