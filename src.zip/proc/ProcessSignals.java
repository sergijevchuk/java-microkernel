package proc;

public class ProcessSignals
{
	public static String SIGNAL_TERM = "proc_term";
	public static String SIGNAL_KILL = "proc_kill";
	public static String SIGNAL_INTER = "prc_interr";
}
