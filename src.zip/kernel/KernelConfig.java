package kernel;

public class KernelConfig
{
	public static boolean isShuttingDown = false;
	public static boolean isShell = false;
	public static boolean isDebug = false;
}
