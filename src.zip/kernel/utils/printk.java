package kernel.utils;
import kernel.*;

public class printk
{
	public static void printk(CharSequence n) {
		if (KernelConfig.isDebug) {
		System.out.println("[" + System.currentTimeMillis() + "]: " + n);
		}
	}
}
